import figures.*;

public class Main {
    public static void main(String[] args) {
        Square square = new Square(5);
        Rectangle rectangle = new Rectangle(4, 6);
        Triangle triangle = new Triangle(3, 4);

        square.printProperties();
        System.out.println();
        rectangle.printProperties();
        System.out.println();
        triangle.printProperties();
    }
}






